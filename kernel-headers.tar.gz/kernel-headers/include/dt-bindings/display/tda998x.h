/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _DT_BINDINGS_TDA998X_H
#define _DT_BINDINGS_TDA998X_H

#define TDA998x_SPDIF	1
#define TDA998x_I2S	2

#endif /*_DT_BINDINGS_TDA998X_H */
