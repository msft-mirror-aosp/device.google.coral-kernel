#ifndef _CRYPTO_GCM_H
#define _CRYPTO_GCM_H

#define GCM_AES_IV_SIZE 12
#define GCM_RFC4106_IV_SIZE 8
#define GCM_RFC4543_IV_SIZE 8

#endif
