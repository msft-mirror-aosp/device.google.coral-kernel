#define UTS_RELEASE "4.14.49-g207b7b1c3785-dirty_audio-g630d9f3"
