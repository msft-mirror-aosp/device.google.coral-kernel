/* This file is auto generated, version 1 */
/* SMP PREEMPT */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#1 SMP PREEMPT Tue Sep 4 20:15:48 PDT 2018"
#define LINUX_COMPILE_BY "achant"
#define LINUX_COMPILE_HOST "achant0.mtv.corp.google.com"
#define LINUX_COMPILER "Android clang version 5.0.1 (https://us3-mirror-android.googlesource.com/toolchain/clang 00e4a5a67eb7d626653c23780ff02367ead74955) (https://us3-mirror-android.googlesource.com/toolchain/llvm ef376ecb7d9c1460216126d102bb32fc5f73800d) (based on LLVM 5.0.1svn)"
